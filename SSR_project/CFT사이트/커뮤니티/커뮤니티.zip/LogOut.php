<?php
include "dlib.php";
$_SESSION['isLogin']="";
$_SESSION['id_cheack']="";
echo "로그아웃 됨!";
?>
<script>
location.href="login2.php"
</script>
