<?php
    session_start();
    error_reporting(1);
    ini_set("display_errors",1);
    $connet=mysqli_connect("localhost","db명","비밀번호", "사용자이름");
    if(mysqli_connect_error()){
        echo mysqli_connect_error();
    }
?>